#! Flux3D 12.0

meshDomain()

generateSecondOrderElements()

buildMagneticCircuitCut()